#include <iostream>
using namespace std;

/*
 * This function is a simplistic cpp function to test insertion stream operator and escape sequences
*/


int main () {

    cout << "My name is: Pratiksha Pai" << endl;
    cout << "This (\") is a double quote." << endl;
    cout << "This (') is a single quote." << endl;
    cout << "This (\\) is a backslash." << endl;
    cout << "This (/) is a forward slash." << endl;

    return 0;
}
